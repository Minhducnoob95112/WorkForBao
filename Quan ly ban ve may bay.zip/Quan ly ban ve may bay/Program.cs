var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();

// 1. Phục vụ file tĩnh từ wwwroot
app.UseStaticFiles();

app.UseRouting();
app.UseAuthorization();

// 2. Map route mặc định (BỎ .WithStaticAssets())
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();