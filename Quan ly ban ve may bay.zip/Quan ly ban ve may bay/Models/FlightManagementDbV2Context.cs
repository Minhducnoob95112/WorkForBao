﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Quan_ly_ban_ve_may_bay.Models;

public partial class FlightManagementDbV2Context : DbContext
{
    public FlightManagementDbV2Context()
    {
    }

    public FlightManagementDbV2Context(DbContextOptions<FlightManagementDbV2Context> options)
        : base(options)
    {
    }

    public virtual DbSet<Aircraft> Aircraft { get; set; }

    public virtual DbSet<Airport> Airports { get; set; }

    public virtual DbSet<Booking> Bookings { get; set; }

    public virtual DbSet<Flight> Flights { get; set; }

    public virtual DbSet<FlightPricing> FlightPricings { get; set; }

    public virtual DbSet<Passenger> Passengers { get; set; }

    public virtual DbSet<TicketClass> TicketClasses { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=.;Database=FlightManagementDB_v2;Trusted_Connection=True;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Aircraft>(entity =>
        {
            entity.HasKey(e => e.AircraftId).HasName("PK__Aircraft__04015399EAE0E3D5");

            entity.Property(e => e.AircraftId).HasColumnName("aircraft_id");
            entity.Property(e => e.Manufacturer)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("manufacturer");
            entity.Property(e => e.Model)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("model");
            entity.Property(e => e.TotalCapacity).HasColumnName("total_capacity");
        });

        modelBuilder.Entity<Airport>(entity =>
        {
            entity.HasKey(e => e.AirportCode).HasName("PK__Airport__E949ADC69BAAC0C4");

            entity.ToTable("Airport");

            entity.Property(e => e.AirportCode)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("airport_code");
            entity.Property(e => e.City)
                .HasMaxLength(50)
                .HasColumnName("city");
            entity.Property(e => e.Country)
                .HasMaxLength(50)
                .HasColumnName("country");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");
        });

        modelBuilder.Entity<Booking>(entity =>
        {
            entity.HasKey(e => e.BookingId).HasName("PK__Booking__5DE3A5B14BB8B2FC");

            entity.ToTable("Booking");

            entity.HasIndex(e => new { e.FlightId, e.SeatNumber }, "UQ__Booking__FC7CEEBF39A68098").IsUnique();

            entity.Property(e => e.BookingId).HasColumnName("booking_id");
            entity.Property(e => e.BookingDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("booking_date");
            entity.Property(e => e.ClassId).HasColumnName("class_id");
            entity.Property(e => e.FinalPrice)
                .HasColumnType("decimal(12, 2)")
                .HasColumnName("final_price");
            entity.Property(e => e.FlightId).HasColumnName("flight_id");
            entity.Property(e => e.PassengerId).HasColumnName("passenger_id");
            entity.Property(e => e.SeatNumber)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("seat_number");
            entity.Property(e => e.Status)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasDefaultValue("Confirmed")
                .HasColumnName("status");

            entity.HasOne(d => d.Class).WithMany(p => p.Bookings)
                .HasForeignKey(d => d.ClassId)
                .HasConstraintName("FK__Booking__class_i__66603565");

            entity.HasOne(d => d.Flight).WithMany(p => p.Bookings)
                .HasForeignKey(d => d.FlightId)
                .HasConstraintName("FK__Booking__flight___656C112C");

            entity.HasOne(d => d.Passenger).WithMany(p => p.Bookings)
                .HasForeignKey(d => d.PassengerId)
                .HasConstraintName("FK__Booking__passeng__6477ECF3");
        });

        modelBuilder.Entity<Flight>(entity =>
        {
            entity.HasKey(e => e.FlightId).HasName("PK__Flight__E370576524BD99CC");

            entity.ToTable("Flight");

            entity.HasIndex(e => e.FlightNumber, "UQ__Flight__340D78BBD192C332").IsUnique();

            entity.Property(e => e.FlightId).HasColumnName("flight_id");
            entity.Property(e => e.AircraftId).HasColumnName("aircraft_id");
            entity.Property(e => e.ArrivalAirportCode)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("arrival_airport_code");
            entity.Property(e => e.ArrivalTime)
                .HasColumnType("datetime")
                .HasColumnName("arrival_time");
            entity.Property(e => e.DepartureAirportCode)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("departure_airport_code");
            entity.Property(e => e.DepartureTime)
                .HasColumnType("datetime")
                .HasColumnName("departure_time");
            entity.Property(e => e.FlightNumber)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("flight_number");
            entity.Property(e => e.Status)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasDefaultValue("Scheduled")
                .HasColumnName("status");

            entity.HasOne(d => d.Aircraft).WithMany(p => p.Flights)
                .HasForeignKey(d => d.AircraftId)
                .HasConstraintName("FK__Flight__aircraft__52593CB8");

            entity.HasOne(d => d.ArrivalAirportCodeNavigation).WithMany(p => p.FlightArrivalAirportCodeNavigations)
                .HasForeignKey(d => d.ArrivalAirportCode)
                .HasConstraintName("FK__Flight__arrival___5165187F");

            entity.HasOne(d => d.DepartureAirportCodeNavigation).WithMany(p => p.FlightDepartureAirportCodeNavigations)
                .HasForeignKey(d => d.DepartureAirportCode)
                .HasConstraintName("FK__Flight__departur__5070F446");
        });

        modelBuilder.Entity<FlightPricing>(entity =>
        {
            entity.HasKey(e => e.PricingId).HasName("PK__FlightPr__A25A9FB7643D3826");

            entity.ToTable("FlightPricing");

            entity.HasIndex(e => new { e.FlightId, e.ClassId }, "UQ__FlightPr__9CAF10FC595AF368").IsUnique();

            entity.Property(e => e.PricingId).HasColumnName("pricing_id");
            entity.Property(e => e.AvailableSeats).HasColumnName("available_seats");
            entity.Property(e => e.BasePrice)
                .HasColumnType("decimal(12, 2)")
                .HasColumnName("base_price");
            entity.Property(e => e.ClassId).HasColumnName("class_id");
            entity.Property(e => e.CurrentPrice)
                .HasColumnType("decimal(12, 2)")
                .HasColumnName("current_price");
            entity.Property(e => e.FlightId).HasColumnName("flight_id");
            entity.Property(e => e.LastUpdated)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("last_updated");

            entity.HasOne(d => d.Class).WithMany(p => p.FlightPricings)
                .HasForeignKey(d => d.ClassId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__FlightPri__class__5EBF139D");

            entity.HasOne(d => d.Flight).WithMany(p => p.FlightPricings)
                .HasForeignKey(d => d.FlightId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__FlightPri__fligh__5DCAEF64");
        });

        modelBuilder.Entity<Passenger>(entity =>
        {
            entity.HasKey(e => e.PassengerId).HasName("PK__Passenge__037645866408AF9C");

            entity.ToTable("Passenger");

            entity.HasIndex(e => e.Email, "UQ__Passenge__AB6E61643A1A4D5D").IsUnique();

            entity.HasIndex(e => e.PassportNumber, "UQ__Passenge__D2CA62993F7F10D2").IsUnique();

            entity.Property(e => e.PassengerId).HasColumnName("passenger_id");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("email");
            entity.Property(e => e.FirstName)
                .HasMaxLength(50)
                .HasColumnName("first_name");
            entity.Property(e => e.LastName)
                .HasMaxLength(50)
                .HasColumnName("last_name");
            entity.Property(e => e.PassportNumber)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("passport_number");
            entity.Property(e => e.PhoneNumber)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("phone_number");
        });

        modelBuilder.Entity<TicketClass>(entity =>
        {
            entity.HasKey(e => e.ClassId).HasName("PK__TicketCl__FDF47986705EB4D3");

            entity.ToTable("TicketClass");

            entity.HasIndex(e => e.ClassName, "UQ__TicketCl__7DC4C39D2CAE0EAC").IsUnique();

            entity.Property(e => e.ClassId).HasColumnName("class_id");
            entity.Property(e => e.ClassName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("class_name");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
