﻿using System;
using System.Collections.Generic;

namespace Quan_ly_ban_ve_may_bay.Models;

public partial class Aircraft
{
    public int AircraftId { get; set; }

    public string Model { get; set; } = null!;

    public int TotalCapacity { get; set; }

    public string? Manufacturer { get; set; }

    public virtual ICollection<Flight> Flights { get; set; } = new List<Flight>();
}
