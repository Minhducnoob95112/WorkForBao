﻿using System;
using System.Collections.Generic;

namespace Quan_ly_ban_ve_may_bay.Models;

public partial class Booking
{
    public int BookingId { get; set; }

    public int? PassengerId { get; set; }

    public int? FlightId { get; set; }

    public int? ClassId { get; set; }

    public string? SeatNumber { get; set; }

    public DateTime? BookingDate { get; set; }

    public decimal FinalPrice { get; set; }

    public string? Status { get; set; }

    public virtual TicketClass? Class { get; set; }

    public virtual Flight? Flight { get; set; }

    public virtual Passenger? Passenger { get; set; }
}
