﻿using System;
using System.Collections.Generic;

namespace Quan_ly_ban_ve_may_bay.Models;

public partial class Airport
{
    public string AirportCode { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string City { get; set; } = null!;

    public string Country { get; set; } = null!;

    public virtual ICollection<Flight> FlightArrivalAirportCodeNavigations { get; set; } = new List<Flight>();

    public virtual ICollection<Flight> FlightDepartureAirportCodeNavigations { get; set; } = new List<Flight>();
}
