﻿using System;
using System.Collections.Generic;

namespace Quan_ly_ban_ve_may_bay.Models;

public partial class TicketClass
{
    public int ClassId { get; set; }

    public string ClassName { get; set; } = null!;

    public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();

    public virtual ICollection<FlightPricing> FlightPricings { get; set; } = new List<FlightPricing>();
}
