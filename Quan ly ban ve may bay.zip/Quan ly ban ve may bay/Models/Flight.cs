﻿using System;
using System.Collections.Generic;

namespace Quan_ly_ban_ve_may_bay.Models;

public partial class Flight
{
    public int FlightId { get; set; }

    public string FlightNumber { get; set; } = null!;

    public string? DepartureAirportCode { get; set; }

    public string? ArrivalAirportCode { get; set; }

    public int? AircraftId { get; set; }

    public DateTime DepartureTime { get; set; }

    public DateTime ArrivalTime { get; set; }

    public string? Status { get; set; }

    public virtual Aircraft? Aircraft { get; set; }

    public virtual Airport? ArrivalAirportCodeNavigation { get; set; }

    public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();

    public virtual Airport? DepartureAirportCodeNavigation { get; set; }

    public virtual ICollection<FlightPricing> FlightPricings { get; set; } = new List<FlightPricing>();
}
