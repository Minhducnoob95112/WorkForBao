﻿using System;
using System.Collections.Generic;

namespace Quan_ly_ban_ve_may_bay.Models;

public partial class FlightPricing
{
    public int PricingId { get; set; }

    public int FlightId { get; set; }

    public int ClassId { get; set; }

    public decimal BasePrice { get; set; }

    public decimal CurrentPrice { get; set; }

    public int AvailableSeats { get; set; }

    public DateTime? LastUpdated { get; set; }

    public virtual TicketClass Class { get; set; } = null!;

    public virtual Flight Flight { get; set; } = null!;
}
