using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Quan_ly_ban_ve_may_bay.Views.Booking
{
    public class MyBookingsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
