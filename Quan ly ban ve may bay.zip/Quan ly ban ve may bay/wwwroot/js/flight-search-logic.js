﻿document.addEventListener('DOMContentLoaded', async function () {
    const airportsList = [
        { code: "HAN", name: "Hà Nội" }, { code: "SGN", name: "Hồ Chí Minh" },
        { code: "DAD", name: "Đà Nẵng" }, { code: "CXR", name: "Nha Trang" },
        { code: "PQC", name: "Phú Quốc" }, { code: "VCA", name: "Cần Thơ" },
        { code: "DLI", name: "Đà Lạt" }, { code: "ICN", name: "Seoul (Incheon)" },
        { code: "PUS", name: "Busan" }, { code: "CJU", name: "Jeju" },
        { code: "TAE", name: "Daegu" }, { code: "GMP", name: "Seoul (Gimpo)" }
    ];

    function setupAutocomplete(inputId, dropdownId) {
        const input = document.getElementById(inputId);
        const dropdown = document.getElementById(dropdownId);
        if (!input || !dropdown) return;

        function renderList(filterText) {
            filterText = filterText || "";
            dropdown.innerHTML = "";
            const filtered = airportsList.filter(function (a) {
                return a.code.toLowerCase().includes(filterText.toLowerCase()) ||
                       a.name.toLowerCase().includes(filterText.toLowerCase());
            });

            if (filtered.length === 0) {
                dropdown.innerHTML = '<div style="padding: 12px 16px; font-size: 13px; color: #94a3b8; text-align: center;">Không tìm thấy sân bay</div>';
                return;
            }

            filtered.forEach(function (airport) {
                const div = document.createElement("div");
                div.className = "autocomplete-item";
                div.innerHTML = '<span class="name">' + airport.name + '</span><span class="code">' + airport.code + '</span>';
                div.addEventListener("click", function () {
                    input.value = airport.code;
                    dropdown.classList.remove("show");
                });
                dropdown.appendChild(div);
            });
        }

        input.addEventListener("focus", function () { renderList(input.value); dropdown.classList.add("show"); });
        input.addEventListener("input", function (e) { renderList(e.target.value); dropdown.classList.add("show"); });
        document.addEventListener("click", function (e) {
            if (!input.contains(e.target) && !dropdown.contains(e.target)) { dropdown.classList.remove("show"); }
        });
    }

    setupAutocomplete("thq_textinput_SYQB", "dropdownFrom");
    setupAutocomplete("thq_textinput_nSJb", "dropdownTo");

    const dateInput = document.getElementById("thq_textinput_lV7Y");
    const returnInput = document.getElementById("returnDateInput");

    function getFormattedDate(offsetDays) {
        const d = new Date();
        d.setDate(d.getDate() + offsetDays);
        return String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0') + '/' + d.getFullYear();
    }

    if (dateInput) flatpickr(dateInput, { dateFormat: "d/m/Y", minDate: "today", defaultDate: getFormattedDate(0) });
    const returnPicker = flatpickr(returnInput, { dateFormat: "d/m/Y", minDate: "today", defaultDate: getFormattedDate(3) });

    const tripBtns = document.querySelectorAll('.trip-btn');
    const returnDateGroup = document.getElementById('returnDateGroup');
    let isRoundTrip = false;

    function setTab(tabName) {
        if (tabName === 'Khứ hồi') {
            tripBtns[0].classList.remove('active');
            tripBtns[1].classList.add('active');
            returnDateGroup.style.display = 'flex';
            returnInput.disabled = false;
            if (!returnInput.value) returnPicker.setDate(getFormattedDate(3));
            isRoundTrip = true;
        } else {
            tripBtns[1].classList.remove('active');
            tripBtns[0].classList.add('active');
            returnDateGroup.style.display = 'none';
            returnInput.value = "";
            returnInput.disabled = true;
            isRoundTrip = false;
        }
        fetchAndRender();
    }

    if (tripBtns.length >= 2) {
        tripBtns[0].addEventListener('click', function () { setTab('Một chiều'); });
        tripBtns[1].addEventListener('click', function () { setTab('Khứ hồi'); });
    }

    const swapBtn = document.getElementById('swapBtn');
    const fromInput = document.getElementById('thq_textinput_SYQB');
    const toInput = document.getElementById('thq_textinput_nSJb');
    if (swapBtn && fromInput && toInput) {
        swapBtn.addEventListener('click', function () {
            const temp = fromInput.value; fromInput.value = toInput.value; toInput.value = temp;
            swapBtn.style.transform = 'rotate(180deg)'; setTimeout(function () { swapBtn.style.transform = 'none'; }, 300);
        });
    }

    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('departure_airport_code') && fromInput) fromInput.value = urlParams.get('departure_airport_code');
    if (urlParams.get('arrival_airport_code') && toInput) toInput.value = urlParams.get('arrival_airport_code');
    if (urlParams.get('departure_time') && dateInput) {
        dateInput.value = urlParams.get('departure_time');
        flatpickr(dateInput, { dateFormat: "d/m/Y", minDate: "today", defaultDate: urlParams.get('departure_time') });
    }

    const passSelect = document.getElementById('thq_select_o_J6');
    if (urlParams.get('passengers_count') && passSelect) passSelect.value = urlParams.get('passengers_count');

    if (urlParams.get('return_time') && urlParams.get('return_time') !== '') {
        setTab('Khứ hồi');
        if (returnInput) {
            returnInput.value = urlParams.get('return_time');
            returnPicker.setDate(urlParams.get('return_time'));
        }
    }

    const resultsList = document.querySelector('.results-list');
    const priceSlider = document.querySelector('.price-slider');
    const priceLabels = document.querySelectorAll('.price-range-labels span');

    let currentFlightData = null;
    let currentSortMode = 'price';

    const sortPriceBtn = document.getElementById('sortPrice');
    const sortTimeBtn = document.getElementById('sortTime');
    const sortDurationBtn = document.getElementById('sortDuration');

    function setActiveSort(mode, btn) {
        currentSortMode = mode;
        document.querySelectorAll('.sort-btn').forEach(function (b) { b.classList.remove('active'); });
        btn.classList.add('active');
        renderList();
    }

    if (sortPriceBtn) sortPriceBtn.addEventListener('click', function () { setActiveSort('price', sortPriceBtn); });
    if (sortTimeBtn) sortTimeBtn.addEventListener('click', function () { setActiveSort('time', sortTimeBtn); });
    if (sortDurationBtn) sortDurationBtn.addEventListener('click', function () { setActiveSort('duration', sortDurationBtn); });

    function getMinutes(timeStr) {
        const parts = timeStr.split(':');
        return parseInt(parts[0], 10) * 60 + parseInt(parts[1], 10);
    }

    function getDuration(dep, arr) {
        let diff = getMinutes(arr) - getMinutes(dep);
        if (diff < 0) diff += 24 * 60;
        return diff;
    }

    async function fetchAndRender() {
        if (!resultsList) return;
        resultsList.innerHTML = '<div style="text-align: center; padding: 50px; font-weight: bold; color: var(--color-primary);">Đang tra cứu hệ thống C++... ✈️</div>';

        const fromCode = fromInput ? fromInput.value : 'SGN';
        const toCode = toInput ? toInput.value : 'HAN';
        const dateParam = dateInput ? dateInput.value : '';
        const returnDateParam = isRoundTrip && returnInput ? returnInput.value : '';
        const passengersCount = passSelect ? parseInt(passSelect.value, 10) : 1;

        try {
            const res = await fetch('/api/flights?departure_airport_code=' + fromCode + '&arrival_airport_code=' + toCode + '&departure_time=' + dateParam + '&return_time=' + returnDateParam + '&maxPrice=50000000');
            if (!res.ok) throw new Error('API Error');
            currentFlightData = await res.json();
            currentFlightData.passCount = passengersCount;
            renderList();
        } catch (e) {
            resultsList.innerHTML = '<div style="text-align: center; color: red; padding: 40px; font-weight: bold;">Lỗi kết nối Backend C++. Đảm bảo Server đang chạy ở cổng 8000!</div>';
        }
    }

    function renderList() {
        if (!resultsList || !currentFlightData) return;
        const maxPrice = priceSlider ? parseInt(priceSlider.value, 10) : 50000000;
        const passCount = currentFlightData.passCount || 1;
        let html = '';

        const emptyHTML = '<div style="text-align: center; padding: 40px; border: 2px dashed #ccc; border-radius: 8px; color: #666;">Không tìm thấy chuyến bay phù hợp! Vui lòng thử nới lỏng mức giá hoặc thay đổi bộ lọc.</div>';

        const filterOneWay = document.getElementById('filterOneWay');
        const filterRoundTrip = document.getElementById('filterRoundTrip');
        const showOneWay = filterOneWay ? filterOneWay.checked : true;
        const showRoundTrip = filterRoundTrip ? filterRoundTrip.checked : true;

        let validOneWay = [];
        let validRoundTrip = [];

        if (showOneWay && currentFlightData.outbound) {
            validOneWay = currentFlightData.outbound.filter(function (f) { return (f.price * passCount) <= maxPrice; });
        }

        if (showRoundTrip && currentFlightData.roundTrip) {
            validRoundTrip = currentFlightData.roundTrip.filter(function (c) { return (c.totalPrice * passCount) <= maxPrice; });
        }

        if (currentSortMode === 'price') {
            validOneWay.sort(function (a, b) { return a.price - b.price; });
            validRoundTrip.sort(function (a, b) { return a.totalPrice - b.totalPrice; });
        } else if (currentSortMode === 'time') {
            validOneWay.sort(function (a, b) { return a.departureTime.localeCompare(b.departureTime); });
            validRoundTrip.sort(function (a, b) { return a.outbound.departureTime.localeCompare(b.outbound.departureTime); });
        } else if (currentSortMode === 'duration') {
            validOneWay.sort(function (a, b) { return getDuration(a.departureTime, a.arrivalTime) - getDuration(b.departureTime, b.arrivalTime); });
            validRoundTrip.sort(function (a, b) {
                const durA = getDuration(a.outbound.departureTime, a.outbound.arrivalTime) + getDuration(a.return.departureTime, a.return.arrivalTime);
                const durB = getDuration(b.outbound.departureTime, b.outbound.arrivalTime) + getDuration(b.return.departureTime, b.return.arrivalTime);
                return durA - durB;
            });
        }

        if (!showOneWay && !showRoundTrip) {
            html = emptyHTML;
        } else if (validOneWay.length === 0 && validRoundTrip.length === 0) {
            html = emptyHTML;
        } else {
            html += validOneWay.map(function (f) { return createCard(f, passCount, false); }).join('');
            html += validRoundTrip.map(function (c) { return createCard(c, passCount, true); }).join('');
        }

        resultsList.innerHTML = html;
    }

    function createCard(data, passCount, isCombo) {
        if (!isCombo) {
            const flight = data;
            const priceStr = (flight.price * passCount).toLocaleString('vi-VN');
            return '<div style="background: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); padding: 20px; margin-bottom: 16px; border: 1px solid #eee;">' +
                '<div style="display: flex; justify-content: space-between; align-items: center;">' +
                    '<div style="flex: 1;">' +
                        '<div style="background: var(--color-primary); color: #fff; width: 40px; height: 40px; display: inline-flex; align-items: center; justify-content: center; border-radius: 4px; font-weight: bold; margin-bottom: 8px;">DZ</div>' +
                        '<div><strong style="font-size: 15px;">Dizzy Airline</strong><br><span style="font-size: 12px; color: #666;">Chuyến bay: ' + flight.flightId + '</span><br><span style="font-size: 12px; color: var(--color-primary); font-weight: bold;">📅 ' + flight.date + '</span></div>' +
                    '</div>' +
                    '<div style="flex: 2; display: flex; align-items: center; justify-content: center; gap: 16px;">' +
                        '<div style="text-align: center;"><strong style="font-size: 18px;">' + flight.departureTime + '</strong><br><span style="font-size: 12px; color: #666; font-weight: bold;">' + flight.departure + '</span></div>' +
                        '<div style="flex: 1; text-align: center;"><span style="font-size: 10px; color: #999;">Bay thẳng</span><div style="height: 2px; background: #ddd; margin: 4px 0;"></div></div>' +
                        '<div style="text-align: center;"><strong style="font-size: 18px;">' + flight.arrivalTime + '</strong><br><span style="font-size: 12px; color: #666; font-weight: bold;">' + flight.arrival + '</span></div>' +
                    '</div>' +
                    '<div style="flex: 1; text-align: right; border-left: 1px dashed #eee; padding-left: 16px;">' +
                        '<span style="font-size: 12px; color: #666;">Tổng (' + passCount + ' Khách)</span><br>' +
                        '<strong style="color: var(--color-primary); font-size: 22px;">' + priceStr + ' đ</strong><br>' +
                        '<button onclick="window.location.href=\'/Flight/Booking?flightId=' + flight.flightId + '&from=' + flight.departure + '&to=' + flight.arrival + '&price=' + flight.price + '&passengers=' + passCount + '\'" style="background: var(--color-primary); color: #fff; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; margin-top: 8px; font-weight: bold; width: 100%;">Chọn vé</button>' +
                    '</div>' +
                '</div>' +
            '</div>';
        } else {
            const out = data.outbound;
            const ret = data.return;
            const priceStr = (data.totalPrice * passCount).toLocaleString('vi-VN');
            return '<div style="background: #fff; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); border: 1px solid var(--color-primary); margin-bottom: 20px; overflow: hidden;">' +
                '<div style="background: var(--color-primary); color: #fff; padding: 6px 16px; font-size: 12px; font-weight: bold;">🌟 COMBO KHỨ HỒI TRỌN GÓI</div>' +
                '<div style="padding: 20px; display: flex; align-items: center;">' +
                    '<div style="flex: 3; border-right: 1px dashed #ccc; padding-right: 20px;">' +
                        '<div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px;">' +
                            '<div style="flex: 1;">' +
                                '<span style="font-size: 10px; background: #eee; padding: 3px 8px; border-radius: 4px; font-weight: bold; color: #555;">CHIỀU ĐI</span><br>' +
                                '<span style="font-size: 14px; font-weight: bold; color: var(--color-primary); display: inline-block; margin-top: 4px;">' + out.date + '</span><br><span style="font-size: 11px; color: #666;">' + out.flightId + '</span>' +
                            '</div>' +
                            '<div style="flex: 2; display: flex; align-items: center; gap: 15px; justify-content: center;">' +
                                '<div style="text-align: center;"><strong style="font-size: 16px;">' + out.departureTime + '</strong><br><span style="font-size: 12px; color: #666; font-weight: bold;">' + out.departure + '</span></div>' +
                                '<div style="flex: 1; height: 2px; background: #ddd; position: relative;"><div style="position: absolute; right: -4px; top: -3px; width: 8px; height: 8px; border-top: 2px solid #ddd; border-right: 2px solid #ddd; transform: rotate(45deg);"></div></div>' +
                                '<div style="text-align: center;"><strong style="font-size: 16px;">' + out.arrivalTime + '</strong><br><span style="font-size: 12px; color: #666; font-weight: bold;">' + out.arrival + '</span></div>' +
                            '</div>' +
                        '</div>' +
                        '<div style="display: flex; align-items: center; justify-content: space-between;">' +
                            '<div style="flex: 1;">' +
                                '<span style="font-size: 10px; background: #eee; padding: 3px 8px; border-radius: 4px; font-weight: bold; color: #555;">CHIỀU VỀ</span><br>' +
                                '<span style="font-size: 14px; font-weight: bold; color: var(--color-primary); display: inline-block; margin-top: 4px;">' + ret.date + '</span><br><span style="font-size: 11px; color: #666;">' + ret.flightId + '</span>' +
                            '</div>' +
                            '<div style="flex: 2; display: flex; align-items: center; gap: 15px; justify-content: center;">' +
                                '<div style="text-align: center;"><strong style="font-size: 16px;">' + ret.departureTime + '</strong><br><span style="font-size: 12px; color: #666; font-weight: bold;">' + ret.departure + '</span></div>' +
                                '<div style="flex: 1; height: 2px; background: #ddd; position: relative;"><div style="position: absolute; right: -4px; top: -3px; width: 8px; height: 8px; border-top: 2px solid #ddd; border-right: 2px solid #ddd; transform: rotate(45deg);"></div></div>' +
                                '<div style="text-align: center;"><strong style="font-size: 16px;">' + ret.arrivalTime + '</strong><br><span style="font-size: 12px; color: #666; font-weight: bold;">' + ret.arrival + '</span></div>' +
                            '</div>' +
                        '</div>' +
                    '</div>' +
                    '<div style="flex: 1; text-align: right; padding-left: 20px;">' +
                        '<span style="font-size: 12px; color: #666;">Tổng cộng (' + passCount + ' Khách)</span><br>' +
                        '<strong style="color: var(--color-primary); font-size: 22px;">' + priceStr + ' đ</strong><br>' +
                        '<button onclick="window.location.href=\'/Flight/Booking?flightId=' + out.flightId + '&returnFlightId=' + ret.flightId + '&from=' + fromInput.value + '&to=' + toInput.value + '&price=' + data.totalPrice + '&passengers=' + passCount + '\'" style="background: var(--color-primary); color: #fff; border: none; padding: 12px 16px; border-radius: 6px; cursor: pointer; margin-top: 12px; width: 100%; font-weight: bold; transition: 0.3s;">Chọn Combo</button>' +
                    '</div>' +
                '</div>' +
            '</div>';
        }
    }

    let sliderTimeout;
    if (priceSlider) {
        priceSlider.addEventListener('input', function (e) {
            if (priceLabels.length >= 2) priceLabels[1].textContent = parseInt(e.target.value, 10).toLocaleString('vi-VN') + ' đ';
            clearTimeout(sliderTimeout);
            sliderTimeout = setTimeout(renderList, 300);
        });
    }

    const filterOneWayCheckbox = document.getElementById('filterOneWay');
    const filterRoundTripCheckbox = document.getElementById('filterRoundTrip');
    if (filterOneWayCheckbox) filterOneWayCheckbox.addEventListener('change', renderList);
    if (filterRoundTripCheckbox) filterRoundTripCheckbox.addEventListener('change', renderList);

    const form = document.getElementById('flightSearchForm');
    if (form) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            const from = fromInput ? fromInput.value : '';
            const to = toInput ? toInput.value : '';
            const date = dateInput ? dateInput.value : '';
            const retDate = isRoundTrip && returnInput ? returnInput.value : '';
            const pass = passSelect ? passSelect.value : '';

            const newUrl = window.location.pathname + '?departure_airport_code=' + from + '&arrival_airport_code=' + to + '&departure_time=' + date + '&return_time=' + retDate + '&passengers_count=' + pass;
            window.history.pushState({ path: newUrl }, '', newUrl);
            fetchAndRender();
        });
    }

    fetchAndRender();
});