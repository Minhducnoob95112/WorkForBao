﻿document.addEventListener('DOMContentLoaded', async function () {
    const urlParams = new URLSearchParams(window.location.search);
    const fromCode = urlParams.get('departure_airport_code') || 'SGN';
    const toCode = urlParams.get('arrival_airport_code') || 'HAN';
    const depDate = urlParams.get('departure_time') || '';
    const retDate = urlParams.get('return_time') || '';
    const passCount = parseInt(urlParams.get('passengers_count') || '1', 10);

    const resultsList = document.getElementById('flightResultsList');
    const priceSlider = document.querySelector('.price-slider');
    const maxPriceLabel = document.getElementById('maxPriceLabel');

    let flightData = null;

    async function loadFlights() {
        if (!resultsList) return;
        try {
            const res = await fetch(`/api/flights?departure_airport_code=${fromCode}&arrival_airport_code=${toCode}&departure_time=${depDate}&return_time=${retDate}&maxPrice=50000000`);
            if (!res.ok) throw new Error();
            flightData = await res.json();
            flightData.passCount = passCount;
            render();
        } catch (e) {
            resultsList.innerHTML = '<div style="color:red; text-align:center; padding:30px;">Lỗi tải dữ liệu từ Backend ASP.NET Core!</div>';
        }
    }

    function render() {
        if (!flightData || !resultsList || !priceSlider) return;
        const maxPrice = parseInt(priceSlider.value, 10);
        const oneWays = (flightData.outbound || []).filter(function (f) {
            return (f.price * passCount) <= maxPrice;
        });
        const combos = (flightData.roundTrip || []).filter(function (c) {
            return (c.totalPrice * passCount) <= maxPrice;
        });

        let html = '';
        if (oneWays.length === 0 && combos.length === 0) {
            resultsList.innerHTML = '<div style="text-align:center; padding:40px; border:2px dashed #ccc; border-radius:12px;">Không tìm thấy chuyến bay thỏa điều kiện.</div>';
            return;
        }

        oneWays.forEach(function (f) {
            const priceFormatted = (f.price * passCount).toLocaleString('vi-VN');
            html += `
                <div style="background:#fff; border-radius:10px; padding:20px; margin-bottom:16px; border:1px solid #e2e8f0; display:flex; justify-content:space-between; align-items:center;">
                    <div>
                        <span style="background:var(--color-primary); color:white; padding:4px 8px; border-radius:4px; font-weight:bold; font-size:12px;">DZ</span>
                        <strong style="margin-left:8px;">${f.flightId}</strong> - <span>${f.date}</span>
                        <div style="margin-top:10px; font-size:1.2rem;"><strong>${f.departureTime} (${f.departure})</strong> ➔ <strong>${f.arrivalTime} (${f.arrival})</strong></div>
                    </div>
                    <div style="text-align:right;">
                        <div style="font-size:13px; color:#64748b;">Tổng (${passCount} khách)</div>
                        <div style="font-size:1.5rem; font-weight:800; color:var(--color-primary);">${priceFormatted} đ</div>
                        <button onclick="window.location.href='/Flight/Booking?flightId=${f.flightId}&from=${f.departure}&to=${f.arrival}&price=${f.price}&passengers=${passCount}'" style="background:var(--color-primary); color:white; border:none; padding:10px 20px; border-radius:6px; font-weight:bold; cursor:pointer; margin-top:8px;">Chọn vé</button>
                    </div>
                </div>
            `;
        });

        combos.forEach(function (c) {
            const priceFormatted = (c.totalPrice * passCount).toLocaleString('vi-VN');
            html += `
                <div style="background:#fff; border-radius:10px; padding:20px; margin-bottom:16px; border:2px solid var(--color-primary);">
                    <div style="background:var(--color-primary); color:white; padding:4px 10px; border-radius:4px; font-weight:bold; font-size:12px; display:inline-block; margin-bottom:10px;">🌟 COMBO KHỨ HỒI</div>
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <div>
                            <p>🛫 Chiều đi: <strong>${c.outbound.flightId}</strong> (${c.outbound.departureTime} - ${c.outbound.date})</p>
                            <p>🛬 Chiều về: <strong>${c.return.flightId}</strong> (${c.return.departureTime} - ${c.return.date})</p>
                        </div>
                        <div style="text-align:right;">
                            <div style="font-size:1.5rem; font-weight:800; color:var(--color-primary);">${priceFormatted} đ</div>
                            <button onclick="window.location.href='/Flight/Booking?flightId=${c.outbound.flightId}&returnFlightId=${c.return.flightId}&from=${fromCode}&to=${toCode}&price=${c.totalPrice}&passengers=${passCount}'" style="background:var(--color-primary); color:white; border:none; padding:10px 20px; border-radius:6px; font-weight:bold; cursor:pointer; margin-top:8px;">Chọn Combo</button>
                        </div>
                    </div>
                </div>
            `;
        });

        resultsList.innerHTML = html;
    }

    if (priceSlider) {
        priceSlider.addEventListener('input', function (e) {
            const target = e.target;
            if (target && maxPriceLabel) {
                maxPriceLabel.textContent = parseInt(target.value, 10).toLocaleString('vi-VN') + ' đ';
                render();
            }
        });
    }

    loadFlights();
});