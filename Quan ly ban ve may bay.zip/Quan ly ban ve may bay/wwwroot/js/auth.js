document.addEventListener('DOMContentLoaded', () => {

    // ========================================================
    // 1. TỰ ĐỘNG XÂY DỰNG LẠI CỬA SỔ MODAL (3 TABS)
    // ========================================================
    const existingModal = document.getElementById('authModal');
    if (existingModal) {
        existingModal.innerHTML = `
            <div class="auth-modal-container" id="mainAuthContainer" style="max-width: 400px; transition: max-width 0.3s ease;">
                <button id="closeAuthModal" class="auth-close-btn">&times;</button>
                <div class="auth-tabs" id="mainAuthTabs">
                    <button class="auth-tab-btn active" data-tab="login">Đăng nhập</button>
                    <button class="auth-tab-btn" data-tab="signup">Đăng ký</button>
                    <button class="auth-tab-btn" data-tab="profile" id="tabProfileBtn">Hồ sơ</button>
                </div>
                
                <form id="loginForm" class="auth-form active">
                    <div class="auth-input-group"><label>Email</label><input type="email" required placeholder="VD: email@example.com"></div>
                    <div class="auth-input-group"><label>Mật khẩu</label><input type="password" required placeholder="Nhập mật khẩu"></div>
                    <div style="text-align: right; margin-bottom: 16px;"><a href="#" id="forgotPwLink" style="font-size: 13px; color: var(--color-primary); text-decoration: none; font-weight: 500;">Quên mật khẩu?</a></div>
                    <button type="submit" class="auth-submit-btn btn btn-primary">Đăng nhập</button>
                </form>
                
                <form id="signupForm" class="auth-form">
                    <div style="display: flex; gap: 10px; margin-bottom: 16px;">
                        <div class="auth-input-group" style="flex: 1; margin-bottom: 0;"><label>Họ</label><input type="text" name="last_name" required></div>
                        <div class="auth-input-group" style="flex: 1; margin-bottom: 0;"><label>Tên</label><input type="text" name="first_name" required></div>
                    </div>
                    <div class="auth-input-group"><label>Email</label><input type="email" name="email" required></div>
                    <div class="auth-input-group"><label>Số điện thoại</label><input type="tel" name="phone_number" required></div>
                    <div class="auth-input-group"><label>Số Hộ chiếu / CCCD</label><input type="text" name="passport_number" required></div>
                    <div class="auth-input-group"><label>Mật khẩu</label><input type="password" name="password_hash" required minlength="6"></div>
                    <button type="submit" class="auth-submit-btn btn btn-primary" style="margin-top: 10px;">Tạo tài khoản</button>
                </form>

                <form id="resetForm" class="auth-form">
                    <div style="text-align: center; margin-bottom: 20px; color: #666; font-size: 13.5px;">Nhập Email và CCCD để đổi mật khẩu.</div>
                    <div class="auth-input-group"><label>Email đăng ký</label><input type="email" name="reset_email" required></div>
                    <div class="auth-input-group"><label>Số CCCD / Hộ chiếu</label><input type="text" name="reset_passport" required></div>
                    <div class="auth-input-group"><label>Mật khẩu mới</label><input type="password" name="reset_new_password" required minlength="6"></div>
                    <div style="display: flex; gap: 10px; margin-top: 20px;">
                        <button type="button" id="backToLoginBtn" class="btn-outline" style="flex: 1; padding: 12px; border-radius: 8px; font-weight: bold;">Quay lại</button>
                        <button type="submit" class="auth-submit-btn btn btn-primary" style="flex: 2; margin-top: 0;">Xác nhận</button>
                    </div>
                </form>

                <div id="profileForm" class="auth-form">
                    <div id="profileLoggedOut" style="text-align:center; padding: 30px;">
                        <p style="margin-bottom: 15px; color: #666;">Bạn cần đăng nhập để xem và chỉnh sửa hồ sơ.</p>
                    </div>
                    <form id="profileLoggedInForm" style="display:none;">
                        <div style="display: flex; gap: 20px; flex-wrap: wrap; align-items: flex-start;">
                            <div style="flex: 1; min-width: 140px; display:flex; flex-direction:column; align-items:center; border-right: 1px dashed #eee; padding-right: 15px;">
                                <img id="profileAvatarPreview" src="" style="width: 120px; height: 120px; border-radius: 50%; object-fit: cover; border: 3px solid var(--color-primary); margin-bottom: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
                                
                                <label for="avatarUpload" class="btn-outline btn-sm btn" style="cursor: pointer; width: 100%; text-align: center; font-size: 13px; padding: 10px; border: 1px solid #ccc; border-radius: 6px;">📷 Đổi ảnh từ máy</label>
                                <input type="file" id="avatarUpload" accept="image/*" style="display:none;">
                                <input type="hidden" id="profileAvatarBase64" name="avatar">
                            </div>
                            
                            <div style="flex: 2; min-width: 250px;">
                                <div style="display: flex; gap: 10px; margin-bottom: 12px;">
                                    <div class="auth-input-group" style="flex:1; margin:0;"><label>Họ</label><input type="text" name="lastName" required></div>
                                    <div class="auth-input-group" style="flex:1; margin:0;"><label>Tên</label><input type="text" name="firstName" required></div>
                                </div>
                                <div class="auth-input-group" style="margin-bottom: 12px;">
                                    <label>Email <span style="color:#aaa; font-weight:normal;">(Không thể đổi)</span></label>
                                    <input type="email" name="email" readonly style="background:#f8f9fa; color:#888; cursor:not-allowed;">
                                </div>
                                <div class="auth-input-group" style="margin-bottom: 12px;"><label>Số điện thoại</label><input type="tel" name="phone" required></div>
                                <div class="auth-input-group" style="margin-bottom: 12px;"><label>Số CCCD / Hộ chiếu <span style="color:var(--color-primary); font-weight:normal;">(Auto-fill)</span></label><input type="text" name="passport" required></div>
                                <button type="submit" class="auth-submit-btn btn btn-primary" style="margin-top: 15px; width: 100%;">Lưu thay đổi</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        `;
    }

    if (!document.getElementById('profileDropdownCSS')) {
        const css = `
            .user-dropdown-menu { position: absolute; top: 100%; right: 0; background: #fff; border-radius: 8px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); border: 1px solid #eee; padding: 8px 0; min-width: 180px; z-index: 100; opacity: 0; visibility: hidden; transform: translateY(10px); transition: all 0.2s ease; }
            .user-dropdown-menu.active { opacity: 1; visibility: visible; transform: translateY(0); }
            .user-dropdown-item { display: block; padding: 10px 16px; color: #444; text-decoration: none; font-size: 0.95rem; cursor: pointer; transition: 0.2s; }
            .user-dropdown-item:hover { background: #f8f9fa; color: var(--color-primary); font-weight: 600; }
        `;
        const style = document.createElement('style'); style.id = 'profileDropdownCSS'; style.innerHTML = css; document.head.appendChild(style);
    }

    // ========================================================
    // 2. AUTO-FILL DỮ LIỆU
    // ========================================================
    function autoFillForms() {
        if (localStorage.getItem('dizzy_logged_in') === 'true') {
            const ln = localStorage.getItem('dizzy_user_lastName') || '';
            const fn = localStorage.getItem('dizzy_user_firstName') || '';
            const em = localStorage.getItem('dizzy_user_email') || '';
            const ph = localStorage.getItem('dizzy_user_phone') || '';
            const pp = localStorage.getItem('dizzy_user_passport') || '';

            const safeSet = (id, val) => { const el = document.getElementById(id); if(el && !el.value) el.value = val; };
            safeSet('contactLastName', ln); safeSet('contactFirstName', fn); safeSet('contactEmail', em); safeSet('contactPhone', ph);
            safeSet('passportNum', pp); safeSet('passportInput', pp); safeSet('confirmPassportInput', pp);
        }
    }

    // ========================================================
    // 3. VẼ GIAO DIỆN & QUẢN LÝ HIỂN THỊ TABS
    // ========================================================
    function renderNavbarInstantly() {
        const isLoggedIn = localStorage.getItem('dizzy_logged_in') === 'true';

        const loginTab = document.querySelector('.auth-tab-btn[data-tab="login"]');
        const signupTab = document.querySelector('.auth-tab-btn[data-tab="signup"]');
        const profileTab = document.querySelector('.auth-tab-btn[data-tab="profile"]');

        if (isLoggedIn) {
            if(loginTab) loginTab.style.display = 'none';
            if(signupTab) signupTab.style.display = 'none';
            if(profileTab) profileTab.style.display = 'block';
        } else {
            if(loginTab) loginTab.style.display = 'block';
            if(signupTab) signupTab.style.display = 'block';
            if(profileTab) profileTab.style.display = 'none';
        }

        if (!isLoggedIn) return;

        // CHỈ ĐÈ VÀO CÁC VÙNG CHỨA NÚT AUTH, KHÔNG ĐÈ LÊN CỤM MENU MOBILE 3 SỌC
        const authWrappers = document.querySelectorAll('.auth-buttons-wrapper, .auth-buttons-wrapper-mobile');

        const email = localStorage.getItem('dizzy_user_email') || '';
        const name = localStorage.getItem('dizzy_user_name') || email.split('@')[0];
        const avatar = localStorage.getItem('dizzy_user_avatar');

        const avatarHtml = avatar ?
            `<img src="${avatar}" style="width: 36px; height: 36px; border-radius: 50%; object-fit: cover; border: 2px solid var(--color-primary);">` :
            `<div style="width: 36px; height: 36px; border-radius: 50%; background: var(--color-primary); color: white; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 15px;">${name.charAt(0).toUpperCase()}</div>`;

        const userHtml = `
            <div style="position: relative;" id="userProfileWrapper">
                <div id="userProfileTrigger" style="display: flex; align-items: center; gap: 10px; cursor: pointer; padding: 5px 10px; border-radius: 8px; transition: 0.2s;">
                    ${avatarHtml}
                    <span style="font-weight: 700; font-size: 14px; color: #333;">${name}</span>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#666" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>
                </div>
                <div class="user-dropdown-menu" id="userDropdownMenu">
                    <div class="user-dropdown-item auth-trigger-btn" data-target="profile">👤 Hồ sơ cá nhân</div>
                    <div style="height: 1px; background: #eee; margin: 4px 0;"></div>
                    <div class="user-dropdown-item logout-btn" style="color: #e74c3c;">🚪 Đăng xuất</div>
                </div>
            </div>
        `;

        authWrappers.forEach(wrapper => { wrapper.innerHTML = userHtml; });

        document.querySelectorAll('#userProfileTrigger').forEach(trigger => {
            trigger.addEventListener('click', (e) => {
                e.stopPropagation();
                const menu = trigger.nextElementSibling;
                document.querySelectorAll('.user-dropdown-menu').forEach(m => { if(m !== menu) m.classList.remove('active'); });
                menu.classList.toggle('active');
            });
        });

        document.querySelectorAll('.logout-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                localStorage.clear(); window.location.reload();
            });
        });

        document.getElementById('profileLoggedOut').style.display = 'none';
        document.getElementById('profileLoggedInForm').style.display = 'block';

        const pForm = document.getElementById('profileLoggedInForm');
        if(pForm) {
            pForm.querySelector('input[name="lastName"]').value = localStorage.getItem('dizzy_user_lastName') || '';
            pForm.querySelector('input[name="firstName"]').value = localStorage.getItem('dizzy_user_firstName') || '';
            pForm.querySelector('input[name="email"]').value = email;
            pForm.querySelector('input[name="phone"]').value = localStorage.getItem('dizzy_user_phone') || '';
            pForm.querySelector('input[name="passport"]').value = localStorage.getItem('dizzy_user_passport') || '';
        }

        const avtPreview = document.getElementById('profileAvatarPreview');
        if(avtPreview) avtPreview.src = avatar ? avatar : `https://ui-avatars.com/api/?name=${name}&background=C5281C&color=fff`;
        const avtBase64 = document.getElementById('profileAvatarBase64');
        if(avtBase64) avtBase64.value = avatar || '';

        autoFillForms();
    }

    // ========================================================
    // 4. ĐỒNG BỘ NGẦM (BACKGROUND SYNC) VỚI C++
    // ========================================================
    async function syncProfileData() {
        const isLoggedIn = localStorage.getItem('dizzy_logged_in') === 'true';
        if (!isLoggedIn) return;
        const email = localStorage.getItem('dizzy_user_email');
        try {
            const res = await fetch(`/api/profile?email=${email}`);
            const result = await res.json();
            if(result.success) {
                localStorage.setItem('dizzy_user_lastName', result.data.lastName);
                localStorage.setItem('dizzy_user_firstName', result.data.firstName);
                localStorage.setItem('dizzy_user_phone', result.data.phone);
                localStorage.setItem('dizzy_user_passport', result.data.passport);
                localStorage.setItem('dizzy_user_avatar', result.data.avatar);
                localStorage.setItem('dizzy_user_name', result.data.lastName + ' ' + result.data.firstName);
                renderNavbarInstantly();
            }
        } catch(e) { console.log("Background sync failed"); }
    }

    renderNavbarInstantly();
    syncProfileData();

    // ========================================================
    // 5. NÉN ẢNH MINI TRƯỚC KHI LƯU (CẮT VUÔNG HD 400x400)
    // ========================================================
    const avatarUpload = document.getElementById('avatarUpload');
    if (avatarUpload) {
        avatarUpload.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(event) {
                    const img = new Image();
                    img.onload = function() {
                        const canvas = document.createElement('canvas');
                        const ctx = canvas.getContext('2d');

                        // Cắt hình vuông chuẩn (không méo)
                        const size = Math.min(img.width, img.height);
                        const startX = (img.width - size) / 2;
                        const startY = (img.height - size) / 2;

                        // Độ phân giải 400x400 nét căng
                        canvas.width = 400;
                        canvas.height = 400;

                        ctx.drawImage(img, startX, startY, size, size, 0, 0, 400, 400);

                        // Lưu Base64 với chất lượng 90% (chống vỡ hạt)
                        const compressedBase64 = canvas.toDataURL('image/jpeg', 0.9);

                        document.getElementById('profileAvatarPreview').src = compressedBase64;
                        document.getElementById('profileAvatarBase64').value = compressedBase64;
                    };
                    img.src = event.target.result;
                };
                reader.readAsDataURL(file);
            }
        });
    }

    // ========================================================
    // 6. UI MODAL & TABS BEHAVIOR
    // ========================================================
    const authOverlay = document.getElementById('authModal');
    const authContainer = document.getElementById('mainAuthContainer');

    function switchTab(target) {
        document.querySelectorAll('.auth-tab-btn').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));

        const tabBtn = document.querySelector(`.auth-tab-btn[data-tab="${target}"]`);
        const formDiv = document.getElementById(target + 'Form');

        if (tabBtn && tabBtn.style.display !== 'none') tabBtn.classList.add('active');
        if (formDiv) formDiv.classList.add('active');

        if (target === 'profile' && localStorage.getItem('dizzy_logged_in') === 'true') {
            if(authContainer) authContainer.style.maxWidth = '600px';
        } else {
            if(authContainer) authContainer.style.maxWidth = '400px';
        }
    }

    document.body.addEventListener('click', (e) => {
        const triggerBtn = e.target.closest('.auth-trigger-btn');
        if (triggerBtn) {
            e.preventDefault();
            if(authOverlay) authOverlay.classList.add('active');
            switchTab(triggerBtn.getAttribute('data-target'));
        }

        if (!e.target.closest('#userProfileWrapper')) {
            document.querySelectorAll('.user-dropdown-menu').forEach(m => m.classList.remove('active'));
        }
    });

    const closeBtn = document.getElementById('closeAuthModal');
    if(closeBtn) closeBtn.addEventListener('click', () => { authOverlay.classList.remove('active'); });

    document.querySelectorAll('.auth-tab-btn').forEach(btn => {
        btn.addEventListener('click', function() { switchTab(this.getAttribute('data-tab')); });
    });

    const forgotPwLink = document.getElementById('forgotPwLink');
    if(forgotPwLink) forgotPwLink.addEventListener('click', (e) => {
        e.preventDefault(); switchTab('reset');
        document.getElementById('resetForm').classList.add('active');
    });

    const backToLoginBtn = document.getElementById('backToLoginBtn');
    if(backToLoginBtn) backToLoginBtn.addEventListener('click', () => { switchTab('login'); });

    // ========================================================
    // 7. GỌI API XUỐNG C++
    // ========================================================

    const profileFormSubmit = document.getElementById('profileLoggedInForm');
    if(profileFormSubmit) profileFormSubmit.addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = profileFormSubmit.querySelector('button[type="submit"]');
        btn.textContent = "Đang lưu..."; btn.disabled = true;

        const payload = {
            email: localStorage.getItem('dizzy_user_email'),
            lastName: profileFormSubmit.querySelector('input[name="lastName"]').value,
            firstName: profileFormSubmit.querySelector('input[name="firstName"]').value,
            phone: profileFormSubmit.querySelector('input[name="phone"]').value,
            passport: profileFormSubmit.querySelector('input[name="passport"]').value,
            avatar: document.getElementById('profileAvatarBase64').value
        };

        try {
            const res = await fetch('/api/profile', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
            const data = await res.json();
            if(data.success) {
                localStorage.setItem('dizzy_user_name', payload.lastName + ' ' + payload.firstName);
                localStorage.setItem('dizzy_user_lastName', payload.lastName);
                localStorage.setItem('dizzy_user_firstName', payload.firstName);
                localStorage.setItem('dizzy_user_phone', payload.phone);
                localStorage.setItem('dizzy_user_passport', payload.passport);
                localStorage.setItem('dizzy_user_avatar', payload.avatar);

                renderNavbarInstantly();
                alert("Cập nhật hồ sơ thành công!");
                authOverlay.classList.remove('active');
            } else { alert("Lỗi: " + data.message); }
        } catch(e) { alert("Lỗi kết nối C++!"); }
        finally { btn.textContent = "Lưu thay đổi"; btn.disabled = false; }
    });

    const loginForm = document.getElementById('loginForm');
    if(loginForm) loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (localStorage.getItem('dizzy_logged_in') === 'true') {
            alert("Bạn đang đăng nhập rồi! Vui lòng tải lại trang.");
            return;
        }

        const btn = loginForm.querySelector('button[type="submit"]');
        btn.textContent = "Đang kiểm tra..."; btn.disabled = true;

        const payload = {
            email: loginForm.querySelector('input[type="email"]').value,
            password: loginForm.querySelector('input[type="password"]').value
        };

        try {
            const res = await fetch('/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
            const data = await res.json();
            if (data.success) {
                localStorage.setItem('dizzy_logged_in', 'true');
                localStorage.setItem('dizzy_user_email', data.user.email);
                syncProfileData();
                alert("Đăng nhập thành công!");
                authOverlay.classList.remove('active');
            } else { alert("Lỗi: " + data.message); }
        } catch (err) { alert("Lỗi kết nối C++!"); }
        finally { btn.textContent = "Đăng nhập"; btn.disabled = false; }
    });

    const signupForm = document.getElementById('signupForm');
    if(signupForm) signupForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (localStorage.getItem('dizzy_logged_in') === 'true') {
            alert("Bạn đang đăng nhập! Vui lòng đăng xuất trước khi tạo tài khoản mới.");
            return;
        }

        const btn = signupForm.querySelector('button[type="submit"]');
        btn.textContent = "Đang tạo..."; btn.disabled = true;

        const payload = {
            last_name: signupForm.querySelector('input[name="last_name"]').value,
            first_name: signupForm.querySelector('input[name="first_name"]').value,
            email: signupForm.querySelector('input[name="email"]').value,
            phone_number: signupForm.querySelector('input[name="phone_number"]').value,
            passport_number: signupForm.querySelector('input[name="passport_number"]').value,
            password_hash: signupForm.querySelector('input[name="password_hash"]').value
        };

        try {
            const res = await fetch('/api/signup', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
            const data = await res.json();
            if (data.success) {
                localStorage.setItem('dizzy_logged_in', 'true');
                localStorage.setItem('dizzy_user_email', data.user.email);
                syncProfileData();
                alert("Đăng ký thành công! Chào mừng đến với Dizzy Airline.");
                authOverlay.classList.remove('active');
            } else { alert("Lỗi: " + data.message); }
        } catch (err) { alert("Lỗi kết nối C++!"); }
        finally { btn.textContent = "Tạo tài khoản"; btn.disabled = false; }
    });

    const resetForm = document.getElementById('resetForm');
    if(resetForm) resetForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = resetForm.querySelector('button[type="submit"]');
        btn.textContent = "Đang xử lý..."; btn.disabled = true;

        const payload = {
            email: resetForm.querySelector('input[name="reset_email"]').value,
            passport: resetForm.querySelector('input[name="reset_passport"]').value,
            new_password: resetForm.querySelector('input[name="reset_new_password"]').value
        };

        try {
            const res = await fetch('/api/reset-password', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
            const data = await res.json();
            if (data.success) {
                alert(data.message);
                resetForm.reset();
                switchTab('login');
            } else { alert("Lỗi: " + data.message); }
        } catch(err) { alert("Lỗi kết nối C++!"); }
        finally { btn.textContent = "Xác nhận"; btn.disabled = false; }
    });

    // ========================================================
    // 8. LOGIC FORM ĐĂNG KÝ NHẬN KHUYẾN MÃI (FOOTER)
    // ========================================================
    const newsletterForms = document.querySelectorAll('.footer-newsletter-form');
    newsletterForms.forEach(form => {
        form.addEventListener('submit', (e) => {
            e.preventDefault();

            const inputEmail = form.querySelector('.footer-newsletter-input').value.trim();
            const loggedInEmail = localStorage.getItem('dizzy_user_email');
            const isLoggedIn = localStorage.getItem('dizzy_logged_in') === 'true';
            const submitBtn = form.querySelector('.footer-newsletter-btn');

            if (isLoggedIn && loggedInEmail && inputEmail.toLowerCase() === loggedInEmail.toLowerCase()) {
                submitBtn.textContent = 'Đang chuyển hướng...';
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 300);
            } else {
                const originalText = submitBtn.textContent;
                submitBtn.textContent = 'Đã đăng ký ✓';
                submitBtn.style.backgroundColor = '#27ae60';
                submitBtn.style.borderColor = '#27ae60';

                setTimeout(() => {
                    submitBtn.textContent = originalText;
                    submitBtn.style.backgroundColor = 'var(--color-primary)';
                    submitBtn.style.borderColor = 'var(--color-primary)';
                    form.reset();
                }, 2000);
            }
        });
    });

    // ========================================================
    // 9. LOGIC MENU ĐIỆN THOẠI (HAMBURGER MENU)
    // ========================================================
    const mobileToggleBtn = document.getElementById('nav-mobile-toggle');
    const mobileOverlay = document.getElementById('mobile-overlay');
    const mobileCloseBtn = document.getElementById('nav-mobile-close');

    if (mobileToggleBtn && mobileOverlay) {
        mobileOverlay.style.display = 'none';
        mobileOverlay.style.zIndex = '99999';

        mobileToggleBtn.addEventListener('click', () => {
            mobileOverlay.style.display = 'flex';
            mobileOverlay.style.flexDirection = 'column';
            mobileOverlay.classList.add('animate__animated', 'animate__fadeIn');
        });
    }

    if (mobileCloseBtn && mobileOverlay) {
        mobileCloseBtn.addEventListener('click', () => {
            mobileOverlay.style.display = 'none';
            mobileOverlay.classList.remove('animate__animated', 'animate__fadeIn');
        });
    }

    const mobileLinks = document.querySelectorAll('.navigation-mobile-item a, .auth-buttons-wrapper-mobile button');
    mobileLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (mobileOverlay) {
                mobileOverlay.style.display = 'none';
            }
        });
    });

});