document.addEventListener('DOMContentLoaded', function() {

    // 1. Khởi tạo Flatpickr chọn ngày
    const dateInput = document.getElementById("thq_textinput_lV7Y");
    if (dateInput) {
        flatpickr(dateInput, { dateFormat: "d/m/Y", minDate: "today", defaultDate: "today" });
    }

    // 2. Nút đảo chiều Sân bay
    const swapBtn = document.getElementById('swapBtn');
    const inputFrom = document.getElementById('thq_textinput_SYQB');
    const inputTo = document.getElementById('thq_textinput_nSJb');

    if(swapBtn && inputFrom && inputTo) {
        swapBtn.addEventListener('click', () => {
            const temp = inputFrom.value;
            inputFrom.value = inputTo.value;
            inputTo.value = temp;
            swapBtn.style.transform = 'rotate(180deg)';
            setTimeout(() => swapBtn.style.transform = 'none', 300);
        });
    }

    // 3. Ép bẻ lái sang trang kết quả tìm kiếm (Dành cho index.html)
    const searchForm = document.getElementById('flightSearchForm');
    if(searchForm) {
        searchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const fromCode = (inputFrom && inputFrom.value) ? inputFrom.value.trim().toUpperCase() : 'SGN';
            const toCode = (inputTo && inputTo.value) ? inputTo.value.trim().toUpperCase() : 'HAN';
            window.location.href = `/flight-search.html?departure_airport_code=${fromCode}&arrival_airport_code=${toCode}`;
        });
    }

    // 4. Đồng hồ đếm ngược Khuyến mãi
    const countdownElement = document.getElementById('flash-countdown');
    if (countdownElement) {
        let timer = 2 * 3600 + 45 * 60 + 12; // 2h 45m 12s
        setInterval(function () {
            let hours = parseInt(timer / 3600, 10);
            let minutes = parseInt((timer % 3600) / 60, 10);
            let seconds = parseInt(timer % 60, 10);

            hours = hours < 10 ? "0" + hours : hours;
            minutes = minutes < 10 ? "0" + minutes : minutes;
            seconds = seconds < 10 ? "0" + seconds : seconds;

            countdownElement.textContent = hours + ":" + minutes + ":" + seconds;
            if (--timer < 0) timer = 2 * 3600 + 45 * 60 + 12;
        }, 1000);
    }

    // 5. Code Logic cho Modal Đăng nhập / Đăng ký
    const authModal = document.getElementById('authModal');
    const closeAuthModal = document.getElementById('closeAuthModal');

    document.querySelectorAll('.auth-trigger-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            if(authModal) authModal.classList.add('active');
        });
    });

    if(closeAuthModal) {
        closeAuthModal.addEventListener('click', () => authModal.classList.remove('active'));
    }

    const authTabBtns = document.querySelectorAll('.auth-tab-btn');
    const authForms = document.querySelectorAll('.auth-form');
    authTabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            authTabBtns.forEach(t => t.classList.remove('active'));
            authForms.forEach(f => f.classList.remove('active'));
            btn.classList.add('active');
            const formToShow = document.getElementById(btn.getAttribute('data-tab') + 'Form');
            if(formToShow) formToShow.classList.add('active');
        });
    });
});