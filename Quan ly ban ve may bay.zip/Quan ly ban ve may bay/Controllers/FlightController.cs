﻿// Controllers/FlightController.cs
using Microsoft.AspNetCore.Mvc;

namespace MyFlightProject.Controllers
{
    public class FlightController : Controller
    {
        public IActionResult Search() => View();      // Views/Flight/Search.cshtml (từ flight-search.html)
        public IActionResult Booking() => View();     // Views/Flight/Booking.cshtml (từ booking.html)
        public IActionResult Promotions() => View();  // Views/Flight/Promotions.cshtml
    }
}
