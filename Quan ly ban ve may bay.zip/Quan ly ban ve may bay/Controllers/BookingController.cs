﻿// Controllers/BookingController.cs
using Microsoft.AspNetCore.Mvc;

namespace MyFlightProject.Controllers
{
    public class BookingController : Controller
    {
        public IActionResult MyBookings() => View();  // Views/Booking/MyBookings.cshtml (từ my-bookings.html)
        public IActionResult CheckIn() => View();     // Views/Booking/CheckIn.cshtml (từ check-in.html)
    }
}